# Usage
These are 3 types of images to understand efficiency of our program.  
***Lenna*** (using which is a trend in photographic operations)  
***Babylon*** (it's a grayscale image)  
***Pepper*** (it's a colourful image with fruits)  
> the python program will automatically handle these functions.
